/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */
		
package copnet;

import java.util.*;
import java.io.*;

import peersim.core.Network;
import peersim.graph.Graph;
import peersim.graph.NeighbourListGraph;

/**
* Implenments static methods to load and write graphs.
*/
public class GraphIO {
	static String color[] = new String[100];
	

private GraphIO() {
	

}


// ================== public static methods =========================
// ==================================================================


/**
* Prints graph in edge list format. Each line contains exactly two
* node id-s separated by whitespace.
*/
@SuppressWarnings("rawtypes")
public static void writeEdgeList( Graph g, PrintStream out ) {

	for(int i=0; i<g.size(); ++i)
	{
		Iterator it=g.getNeighbours(i).iterator();
		while(it.hasNext())
		{
			out.println(i+" "+it.next());
		}
	}
}

// ------------------------------------------------------------------

/**
* Prints graph in neighbor list format. Each line starts with the
* id of a node followed by the ids of its neighbors separated by space.
*/
@SuppressWarnings("rawtypes")
public static void writeNeighborList( Graph g, PrintStream out ) {

	out.println("# "+g.size());
	
	for(int i=0; i<g.size(); ++i)
	{
		out.print(i+" ");
		Iterator it=g.getNeighbours(i).iterator();
		while(it.hasNext())
		{
			out.print(it.next()+" ");
		}
		out.println();
	}
}

// ------------------------------------------------------------------

/**
* Saves the given graph to
* the given stream in GML format.
*/
@SuppressWarnings("rawtypes")
public static void writeGML( Graph g, PrintStream out ) {

	out.println("graph [ directed "+(g.directed()?"1":"0"));
	
	for(int i=0; i<g.size(); ++i)
		out.println("node [ id "+i+" ]");
	
	for(int i=0; i<g.size(); ++i)
	{
		Iterator it=g.getNeighbours(i).iterator();
		while(it.hasNext())
		{
			out.println(
				"edge [ source "+i+" target "+it.next()+" ]");
		}
	}
	
	out.println("]");
}

// --------------------------------------------------------------------

/**
* Saves the given graph to
* the given stream to be read by NETMETER. It should be ok also for Pajek.
*/
@SuppressWarnings("rawtypes")
public static void writeNetmeter( Graph g, PrintStream out ) {

	for (int i=0; i < color.length; i++)
		color[i]="Gray20";
	
	color[0]="Salmon";
	color[5]="Gray";
	color[10]="LimeGreen";
	color[15]="CadetBlue";
	color[20]="Pink";
	color[25]="Purple";
	color[30]="Orange";
	color[35]="Cyan";
	color[40]="Yellow";
	color[45]="Red";
	color[50]="Blue";

	color[12]="Cyan";
	color[24]="Yellow";
	color[36]="Red";
	color[48]="Blue";
	
	out.println("*Vertices "+g.size());
	for(int i=0; i<g.size(); ++i)
		out.println((i+1)+" \""+((CopNode)Network.get(i)).getMaxEffort()+"\""+" ic "+color[((CopNode)Network.get(i)).getMaxEffort()]);
//		out.println((i+1)+" \""+((CopNode)Network.get(i)).getMaxEffort()+"\"");
	out.println("*Arcs");
	for(int i=0; i<g.size(); ++i)
	{
		Iterator it=g.getNeighbours(i).iterator();
		while(it.hasNext())
		{
			out.println((i+1)+" "+
				(((Integer)it.next()).intValue()+1)+" 1");
		}
	}
	out.println("*Edges");
}

//--------------------------------------------------------------------

/**
* Saves the given graph to
* the given stream to be read by NETMETER. It should be ok also for Pajek.
*/
public static void writeAttribute(int pid, Graph g, PrintStream out ) {
    CopNode node = null;
    int kind = 0;
    int mcc = 0;
    
	out.println("*node data");
	out.println("ID EFFORT UTILITY DEGREE KIND MCC");
	
	
	
	for(int i=0; i<g.size(); ++i){
				
		node = (CopNode)g.getNode(i);
		
		kind=0;
		if (node.getMaxEffort() <= node.getUtility() &&	g.degree(i) == node.getView())
			kind=1;
		else if (node.getMaxEffort() > node.getUtility() && g.degree(i) == node.getView())
			kind=-1;
		
		
		if ( node.getUtility() > node.getMaxEffort() )
			mcc = 1;
		else if  ( node.getUtility() < node.getMaxEffort() )
			mcc = -1;
		else
			mcc=0;
		
//		out.println((i+1)+" "+node.getID()+" "+node.getMaxEffort()+" "+node.getUtility()+" "+((CopNet)node.getProtocol(pid)).degree() );
		out.println(( ((int)node.getID()) + 1)+" "+node.getMaxEffort()+" "+node.getUtility()+" "+g.degree(i)+" "+kind+" "+mcc);
	}
}

//--------------------------------------------------------------------

/**
* Saves the given graph to
* the given stream to be read by NETMETER. It should be ok also for Pajek.
*/
@SuppressWarnings("rawtypes")
public static void writeNetmeterColor(int pid, Graph g, PrintStream out ) {

	
	CopNode node;
	
	out.println("*Vertices "+g.size());
	for(int i=0; i<g.size(); ++i){
		node = (CopNode)Network.get(i);
		if (node.getMaxEffort() <= node.getUtility() &&
				((CopNet)node.getProtocol(pid)).degree() == node.getView()
			)
			out.println((i+1)+" \""+node.getMaxEffort()+"\""+" ic Blue");
		else if ( ((CopNet)node.getProtocol(pid)).degree() == node.getView())
			out.println((i+1)+" \""+node.getMaxEffort()+"\""+" ic Red");
		else
			out.println((i+1)+" \""+node.getMaxEffort()+"\""+" ic Gray");
	}
	out.println("*Arcs");
	for(int i=0; i<g.size(); ++i)
	{
		Iterator it=g.getNeighbours(i).iterator();
		while(it.hasNext())
		{
			out.println((i+1)+" "+
				(((Integer)it.next()).intValue()+1)+" 1");
		}
	}
	out.println("*Edges");
}

//--------------------------------------------------------------------

@SuppressWarnings("rawtypes")
public static void writeNetmeterBoundary(int pid, Graph g, PrintStream out ) {

	CopNode node;
	CopNet copnet;
	int degree;
	boolean border;
	
	
	out.println("*Vertices "+g.size());
	for(int i=0; i<g.size(); ++i){
		node = (CopNode)Network.get(i);
		copnet = (CopNet)node.getProtocol(pid);
		degree = copnet.degree();
		border=false;
		for (int j=0; !border && j < degree; j++){
			if (node.getMaxEffort() != ((CopNode)copnet.getNeighbor(j)).getMaxEffort())
				border=true;
		}
		if (border)
			out.println((i+1)+" \""+node.getMaxEffort()+"\""+" ic Red");
		else
			out.println((i+1)+" \""+node.getMaxEffort()+"\""+" ic Blue");		
	}
	
	out.println("*Arcs");
	for(int i=0; i<g.size(); ++i)
	{
		Iterator it=g.getNeighbours(i).iterator();
		while(it.hasNext())
		{
			out.println((i+1)+" "+
				(((Integer)it.next()).intValue()+1)+" 1");
		}
	}
	out.println("*Edges");
}

// --------------------------------------------------------------------

/**
* Saves the given graph to
* the given stream in UCINET DL nodelist format.
*/
@SuppressWarnings("rawtypes")
public static void writeUCINET_DL_ORIGINAL( Graph g, PrintStream out ) {

	out.println("DL\nN="+g.size()+"\nFORMAT=NODELIST\nDATA:");
	
	for(int i=0; i<g.size(); ++i)
	{
		out.print(" " + (i+1));
		Iterator it=g.getNeighbours(i).iterator();
		while(it.hasNext())
		{
			out.print(" "+(((Integer)it.next()).intValue()+1));
		}
		out.println();
	}
	out.println();
}

//--------------------------------------------------------------------

/**
* Saves the given graph to
* the given stream in UCINET DL nodelist format.
*/
@SuppressWarnings("rawtypes")
public static void writeUCINET_DL( Graph g, PrintStream out ) {

	int id=0;
	out.println("DL\nN="+g.size()+"\nFORMAT=NODELIST\nDATA:");
	
	for(int i=0; i<g.size(); ++i)
	{
//		out.print(" " + (i+1));
		id = (int)((CopNode)g.getNode(i)).getID();
		out.print(" " + (id+1));
		Iterator it=g.getNeighbours(i).iterator();
		while(it.hasNext())
		{
			int inode = ((Integer)it.next()).intValue();
			id = (int)((CopNode)g.getNode(inode)).getID();
			out.print(" "+(id+1));
		}
		out.println();
	}
	out.println();
}

// --------------------------------------------------------------------

/**
* Saves the given graph to
* the given stream in UCINET DL matrix format.
*/
@SuppressWarnings("rawtypes")
public static void writeUCINET_DLMatrix( Graph g, PrintStream out ) {

	out.println("DL\nN="+g.size()+"\nDATA:");
	
	for(int i=0; i<g.size(); ++i)
	{
		BitSet bs = new BitSet(g.size());
		Iterator it=g.getNeighbours(i).iterator();
		while(it.hasNext())
		{
			bs.set( ((Integer)it.next()).intValue() );
		}
		for(int j=0; j<g.size(); ++j)
		{
			out.print(bs.get(j)?" 1":" 0");
		}
		out.println();
	}
	out.println();
}

// --------------------------------------------------------------------

/**
* Saves the given graph to
* the given stream in Chaco format. We need to output the number of edges
* so they have to be counted first which might not be very efficient.
* Note that this format is designed for undirected graphs only.
*/
@SuppressWarnings("rawtypes")
public static void writeChaco( Graph g, PrintStream out ) {

	if( g.directed() ) System.err.println(
		"warning: you're saving a directed graph in Chaco format");
	
	long edges = 0;
	for(int i=0; i<g.size(); ++i) edges += g.getNeighbours(i).size();
	
	out.println( g.size() + " " + edges/2 );
	
	for(int i=0; i<g.size(); ++i)
	{
		Iterator it=g.getNeighbours(i).iterator();
		while(it.hasNext())
		{
			out.print((((Integer)it.next()).intValue()+1)+" ");
		}
		out.println();
	}
	
	out.println();
}

// -------------------------------------------------------------------

/**
* Read a graph in newscast graph format.
* The format depends on mode, the parameter.
* The file begins with the three byte latin 1 coded "NCG" string followed
* by the int MODE which is the
* given parameter. The formats are the following as a function of mode:
* <ul>
* <li> 1: Begins with cacheSize in binary format (int), followed by the
*     numberOfNodes (int), and then a continuous series of exactly
*     numberOfNodes records, where a record describes a node's
*     neighbours and their timestamps.
*     A record is a series of exactly cacheSize (int,long) pairs where
*     the int is the node id, and the long is the timestamp.
*     Node id-s start from 1. Node id 0 means no node and used if the parent
*     node has less that cacheSize nodes.</li>
* </ul>
* @param file Filename to read
* @param direction If 0, the original directionality is preserved, if 1,
* than each edge is reversed, if 2 then directionalty is dropped and the
* returned graph will be undirected.
*/
@SuppressWarnings("resource")
public static Graph readNewscastGraph( String file, int direction )
throws IOException {
	
	NeighbourListGraph gr = new NeighbourListGraph( direction != 2 );
	FileInputStream fis = new FileInputStream(file);
	DataInputStream dis = new DataInputStream(fis);

	dis.readByte();
	dis.readByte();
	dis.readByte();
	
	final int MODE = dis.readInt();
	if( MODE != 1 ) throw new IOException("Unknown mode "+MODE);
	
	final int CACHESIZE = dis.readInt(); 
	final int GRAPHSIZE = dis.readInt(); 
	
//System.out.println("header: "+MODE+" "+CACHESIZE+" "+GRAPHSIZE);
	
	for(int i=1; i<=GRAPHSIZE; ++i)
	{
		int iind = gr.addNode(new Integer(i));
		
		for(int j=0; j<CACHESIZE; ++j)
		{
			int a = dis.readInt();
			dis.readLong();
			
			int agentIndex = gr.addNode(new Integer(a));
			if( direction == 0 ) gr.setEdge(iind,agentIndex);
			else gr.setEdge(agentIndex,iind);
		}
	}
	
	dis.close();

	return gr;
}


}

