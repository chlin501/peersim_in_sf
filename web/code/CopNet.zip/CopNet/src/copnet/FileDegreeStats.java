/**
 * Reports several statistics about the node degrees in the graph.
 * This Class has beeen derived from the Peersim class DegreeStats  
 * 
 * @author  Stefano Ferriani
 *  
 * @version 1.0
 */
package copnet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import peersim.config.*;
import peersim.core.*;
import peersim.reports.GraphObserver;
import peersim.util.*;

public class FileDegreeStats extends GraphObserver
{

//	--------------------------------------------------------------------------
//	Parameter
//	--------------------------------------------------------------------------

	/* The number of nodes to be used for sampling the degree. 	 */
	private static final String PAR_N = "n";

	/* If defined, then the given number of nodes will be traced.*/
	private static final String PAR_TRACE = "trace";

	/* Selects a method to use when printing results. stats, freq, list (node degree list) */
	private static final String PAR_METHOD = "method";

	/* Selects the types of links to print information about. */
	private static final String PAR_TYPE = "linktype";

	/* Filename to print out stats on node degree. */
	private static final String PAR_FILE_NAME = "filename";
	
	/* Printing the cicle number */
	private static final String PAR_TITLE = "title";

//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------
    
	/** Filename to print out stats on node degree, including path. */
	private final String fileName;
	/** Printing the cicle number */
	private final boolean title;
	
	private final int n;

	private final boolean trace;

	private Node[] traced = null;

	private final String method;

	private final String type;

	private final RandPermutation rp = new RandPermutation(CommonState.r);

	private int nextnode = 0;
	
	private FileOutputStream fos = null;
	private PrintStream pstr = null;


//	--------------------------------------------------------------------------
//	Initialization
//	--------------------------------------------------------------------------

	/**
	 * Standard constructor that reads the configuration parameters.
	 * Invoked by the simulation engine.
	 * @param name the configuration prefix for this class
	 */
	public FileDegreeStats(String name)
	{
		super(name);
		n = Configuration.getInt(name + "." + PAR_N, -1);
		trace = Configuration.contains(name + "." + PAR_TRACE);
		method = Configuration.getString(name + "." + PAR_METHOD, "stats");
		type = Configuration.getString(name + "." + PAR_TYPE, "live");
		title     = Configuration.getBoolean(name + "." + PAR_TITLE, false);
		fileName=Configuration.getString(name + "." + PAR_FILE_NAME, "output/distributions/Degree.dat");
		if ((type.equals("all") || type.equals("dead")) && undir) {
			throw new IllegalParameterException(
					name + "." + PAR_TYPE, " Parameter "+ name + "." +
					PAR_UNDIR + " must not be defined if " + name + "."
					+ PAR_TYPE + "=" + type + ".");
		}

		try {
			fos = new FileOutputStream(fileName);
			pstr = new PrintStream(fos);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

	}

//	--------------------------------------------------------------------------
//	Methods
//	--------------------------------------------------------------------------

	/**
	 * Returns next node to get degree information about.
	 */
	private int nextNodeId()
	{
		if (trace) {
			if (traced == null) {
				int nn = (n < 0 ? Network.size() : n);
				traced = new Node[nn];
				for (int j = 0; j < nn; ++j)
					traced[j] = Network.get(j);
			}
			return traced[nextnode++].getIndex();
		} else
			return rp.next();
	}

//	---------------------------------------------------------------------

	/**
	 * Returns degree information about next node.
	 */
	private int nextDegree()
	{
		final int nodeid = nextNodeId();
		if (type.equals("live")) {
			return g.degree(nodeid);
		} else if (type.equals("all")) {
			return ((OverlayGraph) g).fullDegree(nodeid);
		} else if (type.equals("dead")) {
			return ((OverlayGraph) g).fullDegree(nodeid) - g.degree(nodeid);
		} else
			throw new RuntimeException(name + ": invalid type");
	}

//	---------------------------------------------------------------------

	/**
	 * Prints statistics about node degree. The format of the output is specified
	 * by {@value #PAR_METHOD}. See also the rest of the configuration parameters.
	 * @return always false
	 */
	public boolean execute()
	{
		

		if (title) pstr.println("Cycle # "+CommonState.getTime());
		
		updateGraph();
		if (!trace)
			rp.reset(g.size());
		else
			nextnode = 0;
		final int nn = (n < 0 ? Network.size() : n);

			if (method.equals("stats")) {
				IncrementalStats stats = new IncrementalStats();
				for (int i = 0; i < nn; ++i)
					stats.add(nextDegree());
				pstr.println(name + ": " + stats);
			} else if (method.equals("freq")) {
				IncrementalFreq stats = new IncrementalFreq();
				for (int i = 0; i < nn; ++i)
					stats.add(nextDegree());
				stats.print(pstr);
				pstr.println("\n\n");
			} else if (method.equals("list")) {
				pstr.print(name + ": ");
				for (int i = 0; i < nn; ++i)
					pstr.print(nextDegree() + " ");
				pstr.println();
			}
			else
				System.err.println(name+": unsupported format "+method);
			
			if ((CommonState.getEndTime() - CommonState.getTime())== 1){
				try {
					fos.close();
				} catch (IOException e) {
					throw new RuntimeException(e);
				}
			}
			return false;
		}

	}
