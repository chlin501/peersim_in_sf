package copnet;

/**
 * Reports statistics about clusters utility.
 * This Class has beeen derived from the Peersim class ConnectivityObserver
 * 
 * 
 * @author  Stefano Ferriani
 *  
 * @version 1.0
 */

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Network;
import peersim.reports.GraphObserver;
import peersim.util.IncrementalStats;

public class CopClusterUtility extends GraphObserver
{

//	--------------------------------------------------------------------------
//	Parameters
//	--------------------------------------------------------------------------

	/** Select to output complete statistics (stats) or just mean value (short) */ 
	private static final String PAR_METHOD = "method";
	/** Types of connected clusters "wcc" -> weakly connected, "scc" -> strongly connected  */
	private static final String PAR_TYPE = "type";
	/** Filename to print out stats on node degree. */
	private static final String PAR_FILE_NAME = "filename";
	/** Printing the cicle number */
	private static final String PAR_TITLE = "title";


//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------

	/** Select to output statisrtics (stats) or histogram (freq) */ 
	private final String method;
	/** Types of connected clusters */
	private final String type;
	/** Filename to print out stats on node degree. */
	private final String fileName;
	/** Printing the cicle number */
	private final boolean title;


	private FileOutputStream fos = null;
	private PrintStream pstr = null;
	private String name=null;



//	--------------------------------------------------------------------------
//	Initialization
//	--------------------------------------------------------------------------

	/**
	 * Standard constructor that reads the configuration parameters.
	 * Invoked by the simulation engine.
	 * @param name the configuration prefix for this class
	 */
	public CopClusterUtility(String name)
	{
		super(name);
		this.name=name;
		method = Configuration.getString(name + "." + PAR_METHOD, "stats");
		type = Configuration.getString(name + "." + PAR_TYPE,"wcc");
		fileName=Configuration.getString(name + "." + PAR_FILE_NAME, "output/distributions/cluster_utility.dat");
		title     = Configuration.getBoolean(name + "." + PAR_TITLE, false);

		try {
			fos = new FileOutputStream(fileName);
			pstr = new PrintStream(fos);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

	}

//	--------------------------------------------------------------------------
//	Methods
//	--------------------------------------------------------------------------

	/** Write information about clusters */
	@SuppressWarnings({ "rawtypes", "unused" })
	public boolean execute()
	{
		if (CommonState.getTime()==0)
			return false;

		Map clst;
		updateGraph();

		int vector[];

		if(type.equals("wcc")){
			clst=ga.weaklyConnectedClusters(g);
			vector=ga.color;
		}
		else if(type.equals("scc")){
			clst=ga.tarjan(g);
			vector=ga.root;
		}
		else
			throw new RuntimeException(
					"Unsupported connted cluster type '"+type+"'");


		if (title) pstr.println("Cycle # "+CommonState.getTime());

		Iterator it = clst.values().iterator();
		IncrementalStats statsUtility = new IncrementalStats();
		IncrementalStats statsEffort = new IncrementalStats();

		int color[]=vector.clone();			
		Arrays.sort(color); 

		int clr = Integer.MIN_VALUE;
		int j=0;

		while(j<color.length){
			while (j<color.length && clr==color[j])	j++;
			if (j<vector.length){
				clr=color[j];
				for(int i=0; i < vector.length; i++)
					if (vector[i]==clr){
						statsUtility.add(((CopNode)Network.get(i)).getUtility());
						statsEffort.add(((CopNode)Network.get(i)).getMaxEffort());
					}
				if (method.equals("short"))
					pstr.println(name+" color "+clr+" : "+statsUtility.getAverage()+"  "+statsEffort.getAverage()+"  "+statsUtility.getN());
				else
					pstr.println(name+" color "+clr+" : "+statsUtility+" - "+statsEffort);
				statsUtility.reset();
				statsEffort.reset();
			}
		}	
		pstr.println("\n\n");			



		if ((CommonState.getEndTime() - CommonState.getTime())== 1){
			try {
				fos.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		return false;
	}

}
