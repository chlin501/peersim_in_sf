package copnet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.Map;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.reports.GraphObserver;
import peersim.util.IncrementalFreq;
import peersim.util.IncrementalStats;

/**
 * Reports statistics about weakly or strongly connected clusters.
 * This Class has beeen derived from the Peersim class ConnectivityObserver  
 * 
 * @author  Stefano Ferriani
 *  
 * @version 1.0
 */
public class FileConnectivityObserver extends GraphObserver
{

//	--------------------------------------------------------------------------
//	Parameters
//	--------------------------------------------------------------------------

	/** Select to output statistics (stats) or histogram (freq) */ 
	private static final String PAR_METHOD = "method";
	/** Types of connected clusters "wcc" -> weakly connected, "scc" -> strongly connected  */
	private static final String PAR_TYPE = "type";
	/** Filename to print out stats on node degree. */
	private static final String PAR_FILE_NAME = "filename";
	/** Printing the cicle number */
	private static final String PAR_TITLE = "title";


//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------

	/** Select to output statisrtics (stats) or histogram (freq) */ 
	private final String method;
	/** Types of connected clusters */
	private final String type;
	/** Filename to print out stats on node degree. */
	private final String fileName;
	/** Printing the cicle number */
	private final boolean title;


	private FileOutputStream fos = null;
	private PrintStream pstr = null;
	private String name=null;



//	--------------------------------------------------------------------------
//	Initialization
//	--------------------------------------------------------------------------

	/**
	 * Standard constructor that reads the configuration parameters.
	 * Invoked by the simulation engine.
	 * @param name the configuration prefix for this class
	 */
	public FileConnectivityObserver(String name)
	{
		super(name);
		this.name=name;
		method = Configuration.getString(name + "." + PAR_METHOD, "stats");
		type = Configuration.getString(name + "." + PAR_TYPE,"wcc");
		fileName=Configuration.getString(name + "." + PAR_FILE_NAME, "output/distributions/cluster.dat");
		title     = Configuration.getBoolean(name + "." + PAR_TITLE, false);

		try {
			fos = new FileOutputStream(fileName);
			pstr = new PrintStream(fos);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

	}

//	--------------------------------------------------------------------------
//	Methods
//	--------------------------------------------------------------------------

	/** Write information about clusters */
	@SuppressWarnings({ "rawtypes", "unused" })
	public boolean execute()
	{
		if (CommonState.getTime()==0)
			return false;
		
		Map clst;
		updateGraph();
		
		int vector[];
		
		if(type.equals("wcc")){
			clst=ga.weaklyConnectedClusters(g);
			vector=ga.color;
		}
		else if(type.equals("scc")){
			clst=ga.tarjan(g);
			vector=ga.root;
		}
		else
			throw new RuntimeException(
					"Unsupported connted cluster type '"+type+"'");

		
		if (title) pstr.println("Cycle # "+CommonState.getTime());
		
		Iterator it = clst.values().iterator();
		if (method.equals("stats")){
			IncrementalStats stats = new IncrementalStats();
			while (it.hasNext()) 
				stats.add(((Integer) it.next()).intValue());
			pstr.println(name + ": "+CommonState.getTime()+" "+stats);	
		}
		else if (method.equals("freq")){
			IncrementalFreq  freq = new IncrementalFreq(-1);
			while (it.hasNext()) 
				freq.add(((Integer) it.next()).intValue());
//			pstr.println(name + ": " + freq);
			freq.print(pstr);
			pstr.println("\n\n");			
		}
		else
			System.err.println(name+": unsupported format "+method);
		
		
		if ((CommonState.getEndTime() - CommonState.getTime())== 1){
			try {
				fos.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		return false;
	}

}
