/*
 * Copyright (c) 2003-2005 The BISON Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License version 2 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */

package copnet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import peersim.config.*;
import peersim.core.*;
import peersim.reports.GraphObserver;
import peersim.util.*;

/**
 * Prints several statistics about the node degrees in the graph.
 */
public class CopNodeBound extends GraphObserver
{

//	--------------------------------------------------------------------------
//	Parameter
//	--------------------------------------------------------------------------

	/** Select to output statisrtics (stats) or histogram (freq) */ 
	private static final String PAR_METHOD = "method";
	/** Filename to print out stats on node degree. */
	private static final String PAR_FILE_NAME = "filename";
	/** Printing the cicle number */
	private static final String PAR_TITLE = "title";

//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------

	/** Select to output statisrtics (stats) or histogram (freq) */ 
	private final String method;
	/** Filename to print out stats on node degree. */
	private final String fileName;
	/** Printing the cicle number */
	private final boolean title;
	

	private FileOutputStream fos = null;
	private PrintStream pstr = null;
	private String name=null;


//	--------------------------------------------------------------------------
//	Initialization
//	--------------------------------------------------------------------------

	/**
	 * Standard constructor that reads the configuration parameters.
	 * Invoked by the simulation engine.
	 * @param name the configuration prefix for this class
	 */
	public CopNodeBound(String name)
	{
		super(name);
		this.name=name;
		method = Configuration.getString(name + "." + PAR_METHOD, "stats");
		title     = Configuration.getBoolean(name + "." + PAR_TITLE, false);
		fileName=Configuration.getString(name + "." + PAR_FILE_NAME, "output/distributions/Color.dat");
		
		try {
			fos = new FileOutputStream(fileName);
			pstr = new PrintStream(fos);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

	}


//	---------------------------------------------------------------------

	/**
	 * Prints statistics about node degree. The format of the output is specified
	 * by {@value #PAR_METHOD}. See also the rest of the configuration parameters.
	 * @return always false
	 */
	public boolean execute()
	{

		if (CommonState.getTime()==0)
			return false;
		
		CopNode node;
		CopNet copnet;
		int degree;
		boolean border;		
		
		
		if (title) pstr.println("Cycle # "+CommonState.getTime());

		if (method.equals("stats")) {
			
			IncrementalStats stats = new IncrementalStats();
			
			for(int i = 0; i < Network.size(); i++){
				node = (CopNode)Network.get(i);
				copnet = (CopNet)node.getProtocol(pid);
				degree = copnet.degree();
				border=false;
				for (int j=0; !border && j < degree; j++){
					if (node.getMaxEffort() != ((CopNode)copnet.getNeighbor(j)).getMaxEffort())
						border=true;
				}
				if (border)
					stats.add(0);
				else
					stats.add(1);
			}			
			
			pstr.println(name + ": " + stats);
			
			
			
		}
		else if (method.equals("freq")){
			IncrementalFreq freq = new IncrementalFreq();
			for(int i = 0; i < Network.size(); i++){
				node = (CopNode)Network.get(i);
				copnet = (CopNet)node.getProtocol(pid);
				degree = copnet.degree();
				border=false;
				for (int j=0; !border && j < degree; j++){
					if (node.getMaxEffort() != ((CopNode)copnet.getNeighbor(j)).getMaxEffort())
						border=true;
				}
				if (border)
					freq.add(0);
				else
					freq.add(1);
			}			
			freq.print(pstr);
			pstr.println("\n\n");
		}
		else
			System.out.println(name+" method "+method+" non supported");


		if ((CommonState.getEndTime() - CommonState.getTime())== 1){
			try {
				fos.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		return false;
	}

}
