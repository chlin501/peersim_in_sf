package copnet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import peersim.util.IncrementalFreq;
import peersim.util.IncrementalStats;
/**
 * CopNodeObserver generate a plottable Gnuplot file containing the effort nodes
 * distribution
 * 
 * 
 * 
 * 
 * @author  Stefano Ferriani
 * 
 * @version 1.0
 */


public class CopNodeObserver implements Control {


//	--------------------------------------------------------------------------
//	Parameter
//	--------------------------------------------------------------------------
	
	
    /** Filename base to print out effort distribution, including path. */
    private static final String PAR_FILE_NAME = "filename";
    /** Step for printing value */
    private static final String PAR_STEP = "step";
	/** Maximum effort value */
	public static final String PAR_MAXEFFORT = "maxEffort";

//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------
    
    /** Name of this observer */
    protected final String name;
    /** Filename to print out effort distribution, including path. */
    private final String fileName;
    /** Step for printing value */
    @SuppressWarnings("unused")
	private final long step;
	/** Maximum effort value */
	private int maxEffort;

//	------------------------------------------------------------------------
//	Constructor
//	------------------------------------------------------------------------
	/**
	 * Standard constructor that reads the configuration parameters. Invoked by
	 * the simulation engine.
	 * 
	 * @param prefix
	 *            the configuration prefix for this class.
	 */ 
	public CopNodeObserver(String prefix) {
		this.name = prefix;
		fileName = Configuration.getString(prefix + "." + PAR_FILE_NAME, "output/distributions/effort.dat");
		step     = Configuration.getInt(prefix + "." + PAR_STEP, 1);
		maxEffort = Configuration.getInt(prefix + "." + PAR_MAXEFFORT, 10);
	}


//	------------------------------------------------------------------------
//	Methods
//	------------------------------------------------------------------------
	/**
	 * Write to a file the effort distribution
	 */

	public boolean execute() {

		if (CommonState.getTime()==0){
			try {
				System.out.print(name + ": ");
				// initialize output streams
				
				FileOutputStream fos = new FileOutputStream(fileName);
				System.out.println("Writing to file " + fileName);
				PrintStream ps = new PrintStream(fos);
				IncrementalFreq freq = new IncrementalFreq(maxEffort);
				IncrementalStats stats = new IncrementalStats();
				/** Load the effort values */
				for (int i = 0; i < Network.size(); i++) {
					freq.add(((CopNode)Network.get(i)).getMaxEffort());
					stats.add(((CopNode)Network.get(i)).getMaxEffort());
				}
				/** Write the average effort */				
				ps.println("Effort statistics : "+stats+"\n");
				/** Write the effort distibution */
				for (int i = 0; i <= maxEffort; i++) {
					ps.println(i+ " " + freq.getFreq(i));
				}
				fos.close();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
		
		
		return false;
	}
}
