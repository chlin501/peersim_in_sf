package copnet;

import peersim.core.GeneralNode;

/**
 * CopNode extends the GeneralNode class introducing some variables that store.
 * 
 * 
 * 
 * 
 * @author Stefano Ferriani
 * 
 * @version 1.0
 */

public class CopNode extends GeneralNode {

	/** Starting maximum effort */
	private int maxEffort;

	/** Node utility */
	private int utility;

	/** Drop count */
	private int dropCount;

	/** View */
	private int view;

	public CopNode(String prefix) {
		super(prefix);
	}

	public void setMaxEffort(int value) {
		maxEffort = value;
	}

	public int getMaxEffort() {
		return maxEffort;
	}

	public void setUtility(int value) {
		utility = value;
	}

	public int getUtility() {
		return utility;
	}

	public void setDropCount(int value) {
		dropCount = value;
	}

	public int getDropCount() {
		return dropCount;
	}

	public void setView(int value) {
		view = value;
	}

	public int getView() {
		return view;
	}
}
