package copnet;
/**
 * ClearRndNet remove all node links
 * 
 * 
 * 
 * @author  Stefano Ferriani
 * 
 * @version 1.0
 */

import peersim.config.Configuration;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;

public class CheckCopNet implements Control {


	
//	--------------------------------------------------------------------------
//	Parameter
//	--------------------------------------------------------------------------
	/** Protocol ID */
	public static final String PAR_PROTOCOL = "protocol";


//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------
	/** Protocol ID */
	protected int protocolID;
	protected String name;

//	------------------------------------------------------------------------
//	Constructor
//	------------------------------------------------------------------------
	/**
	 * Standard constructor that reads the configuration parameters. Invoked by
	 * the simulation engine.
	 * 
	 * @param prefix
	 *            the configuration prefix for this class.
	 */ 
	public CheckCopNet(String prefix) {
		protocolID   = Configuration.getInt(prefix+"."+PAR_PROTOCOL);
		name = prefix;
	}


//	------------------------------------------------------------------------
//	Methods
//	------------------------------------------------------------------------
	/**
	 * Remove the link clearing the chache array
	 */

	public boolean execute() {

		int viewSize = ((CopNet)Network.get(0).getProtocol(protocolID)).getViewSize();
		int count=0;
		int ilink=0;
		CopNet copNet;
		Node node;

		System.out.print(name+": Checking nodes ");
		for (int i=0; i < Network.size(); i++){
			copNet = (CopNet)Network.get(i).getProtocol(protocolID);
			node = Network.get(i);
			if ( copNet.degree() !=  viewSize){
//				System.out.println("--- Node "+node.getID()+" has a wrong viewsize: "+copNet.degree());
				count++;
			}
			for (int j=0; j < copNet.degree(); j++){
				if (!((CopNet)copNet.getNeighbor(j).getProtocol(protocolID)).contains(node)){
					System.out.println("--- Node "+node.getID()+" has a unidirectional link");
					ilink++;
				}
			}

		}
		System.out.print("--- NODES UNDER VIEWSIZE : "+count+" - "+(float)count*100/Network.size()+" %  ");
		System.out.println("*** NODES WITH WRONG LINK: "+ilink+" - "+(float)ilink*100/Network.size()+" %");
		return false;
	}
}
