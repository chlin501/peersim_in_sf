package copnet;
/**
 * ClearRndNet remove all node links
 * 
 * 
 * 
 * @author  Stefano Ferriani
 * 
 * @version 1.0
 */

import peersim.config.Configuration;
import peersim.core.Control;
import peersim.core.Network;

public class ClearRndNet implements Control {


//	--------------------------------------------------------------------------
//	Parameter
//	--------------------------------------------------------------------------
	/** Protocol ID */
	public static final String PAR_PROTOCOL = "protocol";


//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------
	/** Protocol ID */
	protected int protocolID;
	protected String name;

//	------------------------------------------------------------------------
//	Constructor
//	------------------------------------------------------------------------
	/**
	 * Standard constructor that reads the configuration parameters. Invoked by
	 * the simulation engine.
	 * 
	 * @param prefix
	 *            the configuration prefix for this class.
	 */ 
	public ClearRndNet(String prefix) {
		protocolID   = Configuration.getInt(prefix+"."+PAR_PROTOCOL);
		name = prefix;
	}


//	------------------------------------------------------------------------
//	Methods
//	------------------------------------------------------------------------
	/**
	 * Remove the link clearing the chache array
	 */

	public boolean execute() {
		
		System.out.println(name+": Clearing");
		for (int i=0; i < Network.size(); i++){
			((RndNet)Network.get(i).getProtocol(protocolID)).cache.clear();
		}
		
		return false;
	}
}
