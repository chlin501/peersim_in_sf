package copnet;

import peersim.core.*;
import peersim.config.*;

import java.util.*;

import peersim.cdsim.CDProtocol;


/**
 * The CopNet protocol. This class implements the mechanism at the core of Communities fo practices interaction.
 * 
 * 
 * 
 * 
 * @author  Stefano Ferriani
 *  
 * @version 1.0
 */

public class RndNet implements CDProtocol, Linkable {

//	--------------------------------------------------------------------------
//	Parameter
//	--------------------------------------------------------------------------
	/** Maximum degree parameter */
	public static final String PAR_VIEWSIZE = "viewsize";


//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------

	/** Nodes neighborhood */
	@SuppressWarnings("rawtypes")
	protected ArrayList cache= null;
	/** Maximum degree of each node -> PAR_DEGREE */
	private int viewSize;

//	------------------------------------------------------------------------
//	Constructor
//	------------------------------------------------------------------------
	/**
	 * Standard constructor that reads the configuration parameters. Invoked by
	 * the simulation engine.
	 * 
	 * @param prefix
	 *            the configuration prefix for this class.
	 */ 

	@SuppressWarnings("rawtypes")
	public RndNet(String prefix) { 
		cache = new ArrayList();
		viewSize   = Configuration.getInt(prefix+"."+PAR_VIEWSIZE);
	}

//	------------------------------------------------------------------------
//	Methods
//	------------------------------------------------------------------------

	/**
	 * Clone object including complex structures
	 */

	@SuppressWarnings("rawtypes")
	public Object clone(){
		RndNet af = null;
		try{ af=(RndNet)super.clone(); }
		catch(CloneNotSupportedException e){}
		af.cache   =(ArrayList)this.cache.clone();
		af.cache.clear();
		return af;
	}

	/**
	 * 	Linkable method implementation
	 */	
	/**  Add a neighbor to the current set of neighbors. */
	@SuppressWarnings("unchecked")
	public boolean addNeighbor(Node n){
		if(cache.contains(n))
			return false;
		else{
			while(cache.size()>=viewSize)
				cache.remove(CommonState.r.nextInt(cache.size()));
			return cache.add(n);
		}
	}

	/** Returns true if the given node is a member of the neighbor set. */
	public boolean contains(Node n){
		return cache.contains(n);
	}

	/** Returns the size of the neighbor list. */
	public int degree(){
		return cache.size();
	}

	/**  Returns the neighbor with the given index.*/
	public Node getNeighbor(int i){
		return (Node)cache.get(i);
	}

	/** Removes node n from the neighbor list */
	public boolean removeNeighbor(Node n){
		return cache.remove(n);
	}

	/** A possibility for optimization */
	public void  pack(){
		return;
	}

	/** Performs cleanup when removed from the network */
	public void onKill(){
		return;
	}


	/***************************************
	 * 	CDProtocl method implementation
	 */		

	public void nextCycle( Node node, int protocolID ){


	}	
}
