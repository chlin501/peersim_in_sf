package copnet;

/**
 * The CopNet protocol. This class implements the mechanism at the core of 
 * peer-to-peer interaction inspired by the weakest-link-game.
 * 
 * 
 * @author  Stefano Ferriani
 *  
 * @version 1.0
 */

import peersim.core.*;
import peersim.config.*;

import java.util.*;

import peersim.cdsim.CDProtocol;

public class CopNet implements CDProtocol, Linkable {

	// --------------------------------------------------------------------------
	// Parameter
	// --------------------------------------------------------------------------
	/** Maximum degree parameter */
	public static final String PAR_VIEWSIZE = "viewsize";

	/** Number of game cycles */
	public static final String PAR_GAMESTEP = "gamestep";

	/** Rewire probability */
	public static final String PAR_REWIREPROB = "rewireprob";

	/** Treshold for dropping */
	public static final String PAR_TRESHOLD = "threshold";

	/** Drop method */
	public static final String PAR_METHOD = "method";

	/** Link cost */
	public static final String PAR_COST = "cost";
	
	/** Monitoring cost */
	public static final String PAR_MONITORINGCOST = "mcost";


	// --------------------------------------------------------------------------
	// Fields
	// --------------------------------------------------------------------------

	/** Nodes neighborhood */
	@SuppressWarnings("rawtypes")
	protected ArrayList cache = null;

	/** Maximum degree of each node -> PAR_DEGREE */
	private int viewSize;

	/** Number of game cycles */
	private int gameStep;

	/** Treshold for dropping */
	private int threshold;

	/** Drop method */
	protected String method;

	/** Link cost */
	protected int cost;
	
	/** Monitoring cost */
	protected int mcost;

	/** Nodes to drop */
	protected boolean[] toDrop;

	/** Nodes to play with */
	protected boolean[] toPlay;

	/** Node investment */
	protected int investment[];

	/** Node potential gain */
	protected int gain[];

	/* Node effort */
	int effort[];

	/* Neighbors effort */
	int other[];

	/* Weakest gain */
	int wktGain[];

	/** The associated node */
	private CopNode copnode;

	/** The protocolID */
	private int pID;

	int rewireCount;

	// ------------------------------------------------------------------------
	// Constructor
	// ------------------------------------------------------------------------
	/**
	 * Standard constructor that reads the configuration parameters. Invoked by
	 * the simulation engine.
	 * 
	 * @param prefix
	 *            the configuration prefix for this class.
	 */

	@SuppressWarnings("rawtypes")
	public CopNet(String prefix) {
		cache = new ArrayList();
		viewSize = Configuration.getInt(prefix + "." + PAR_VIEWSIZE, 5);
		gameStep = Configuration.getInt(prefix + "." + PAR_GAMESTEP, 3);
		threshold = Configuration.getInt(prefix + "." + PAR_TRESHOLD, 1);
		method = Configuration.getString(prefix + "." + PAR_METHOD, "min");
		cost = Configuration.getInt(prefix + "." + PAR_COST, 0);
		mcost = Configuration.getInt(prefix + "." + PAR_MONITORINGCOST, 0);
		toDrop = new boolean[viewSize];
		toPlay = new boolean[viewSize];
		investment = new int[viewSize];
		gain = new int[viewSize];
		effort = new int[viewSize];
		other = new int[viewSize];
		wktGain = new int[viewSize];

		for (int i = 0; i < viewSize; i++) {
			toDrop[i] = false;
			toPlay[i] = true;
			investment[i] = 0;
			gain[i] = 0;
			effort[i] = 0;
			other[i] = 0;
			wktGain[i] = 0;
		}
	}

	// ------------------------------------------------------------------------
	// Methods
	// ------------------------------------------------------------------------

	/**
	 * Clone object including complex structures
	 */

	@SuppressWarnings("rawtypes")
	public Object clone() {
		CopNet af = null;
		try {
			af = (CopNet) super.clone();
		} catch (CloneNotSupportedException e) {
		}
		af.cache = (ArrayList) this.cache.clone();
		af.cache.clear();
		af.toDrop = this.toDrop.clone();
		af.toPlay = this.toPlay.clone();
		af.investment = this.investment.clone();
		af.gain = this.gain.clone();
		af.effort = this.effort.clone();
		af.other = this.other.clone();
		af.wktGain = this.wktGain.clone();
		return af;
	}

	/**
	 * Linkable method implementation
	 */
	/** Add a neighbor to the current set of neighbors. */
	@SuppressWarnings("unchecked")
	public boolean addNeighbor(Node n) {
		if (cache.contains(n))
			return false;
		else {
			while (cache.size() >= viewSize)
				cache.remove(CommonState.r.nextInt(cache.size()));
			return cache.add(n);
		}
	}

	/** Returns true if the given node is a member of the neighbor set. */
	public boolean contains(Node n) {
		return cache.contains(n);
	}

	/** Returns the size of the neighbor list. */
	public int degree() {
		return cache.size();
	}

	/** Returns the neighbor with the given index. */
	public Node getNeighbor(int i) {
		return (Node) cache.get(i);
	}

	/** Removes node n from the neighbor list */
	public boolean removeNeighbor(Node n) {
		return cache.remove(n);
	}

	/** A possibility for optimization */
	public void pack() {
		return;
	}

	/** Performs cleanup when removed from the network */
	public void onKill() {
		return;
	}

	/***************************************************************************
	 * CDProtocl method implementation
	 */

	public void nextCycle(Node node, int protocolID) {

		/** For semplifying method calls node and pID variables has to be set */
		if (CommonState.getIntTime() == 0) {
			copnode = (CopNode) node;
			pID = protocolID;
			copnode.setView(viewSize);
		}
		if (CommonState.getIntTime() % 2 == 1)
			drop();
		else {
			rewire();
			if (this.degree() > 0)
				play();
		}
	}

	/** REWIRE */
	private void rewire() {

		rewireCount = 0;

		/** Get the linkable node's protocols defined in the configuration */
		int linkID = FastConfig.getLinkable(pID);
		Linkable rnd = (Linkable) copnode.getProtocol(linkID);
		/** Add the neighbor of linkable protocol to the current node */
		for (int i = this.degree(), j = 0; i < viewSize && j < rnd.degree(); j++) {
			if (!this.contains(rnd.getNeighbor(j))
					&& ((CopNet) rnd.getNeighbor(j).getProtocol(pID)).degree() < viewSize) {
				this.addNeighbor(rnd.getNeighbor(j));
				((CopNet) rnd.getNeighbor(j).getProtocol(pID))
						.addNeighbor(copnode);
				i++;
				rewireCount++;
			}
		}
	}

	/** DROP */
	private void drop() {
		/** Load and evaluate strategy's statistics */
		int idrop = 0;
		int size = this.degree();
		for (int i = 0, j = 0; i < size; i++) {
			toPlay[i] = true;
			if (toDrop[i]) {
				toDrop[i] = false;
				this.removeNeighbor(this.getNeighbor(j));
				idrop++;
			} else
				j++;
		}
		copnode.setDropCount(idrop);
	}

	/** PLAY */
	@SuppressWarnings("unused")
	private void play() {

		/* Differences between node and neighbor values */
		int delta[] = new int[this.degree()];

		/* The first interaction */
		for (int i = 0; i < this.degree(); i++) {
			if (toPlay[i]) {
				setNeighborToPlay(i, false);
				setNeighborEffort(i);
				effort[i] = copnode.getMaxEffort();
				other[i] = getNeighborEffort(i);
				delta[i] = effort[i] - other[i];
				investment[i] = effort[i];
				gain[i] = other[i];
				wktGain[i] = Math.min(effort[i], other[i]);
			}
		}

		/* The remaining interaction */
		for (int i = 0; i < this.degree(); i++) {
			for (int j = 1; j < gameStep; j++) {
				if ((toPlay[i])) {
					
//					int ud = Math.abs(delta[i]);
//					int var = CommonState.r.nextInt(ud + 1);
//					effort[i] = (delta[i] > 0) ? effort[i] - var : effort[i]
//							+ var;
//					var = CommonState.r.nextInt(ud + 1);
//					other[i] = (delta[i] > 0) ? other[i] + var : other[i] - var;
//					delta[i] = effort[i] - other[i];
//					investment[i] += effort[i];
//					gain[i] += other[i];
//					wktGain[i] += Math.min(effort[i], other[i]);				
//					int ud = Math.abs(delta[i]);
					
					int var=(int)(CommonState.r.nextFloat()*delta[i]);
					effort[i] = effort[i] - var;
					var=(int)(CommonState.r.nextFloat()*delta[i]);
					other[i] = other[i] + var;
					delta[i] = effort[i] - other[i];
					investment[i] += effort[i];
					gain[i] += other[i];
					wktGain[i] += Math.min(effort[i], other[i]);							
				}
			}
		}

		/*
		 * Set the nodes values just played and retrieve those previously
		 * evaluated
		 */
		for (int i = 0; i < this.degree(); i++) {
			if ((toPlay[i])) {
				toPlay[i] = false;
				setNeighborInvestment(i, gain[i]);
				setNeighborGain(i, investment[i]);
				setNeighborWktGain(i, wktGain[i]);
			} else
				gain[i] = getNeighborInvestment(i);
			    investment[i] = getNeighborGain(i);
			    wktGain[i] = getNeighborWktGain(i);
		}

		/* Find the minimum gain */
		int utility = 0;
		int loss = 0;
		int min = Integer.MAX_VALUE;
		int max = Integer.MIN_VALUE;
		int imin = 0;
		int imax = 0;
		for (int i = 0; i < this.degree(); i++) {
			utility += wktGain[i];
			loss += investment[i];
			if (wktGain[i] < min) {
				min = wktGain[i];
				imin = i;
			}
			if (wktGain[i] > max) {
				max = wktGain[i];
				imax = i;
			}
		}

		if (method.equals("min")) {
			/** Remove the threshold minimum wktGain values */
			int wktSort[] = wktGain.clone();
			Arrays.sort(wktSort);
			int off = viewSize - this.degree();
			for (int i = 0; i < this.degree() && i < threshold; i++) {
				boolean go = true;
				for (int j = 0; go && j < this.degree(); j++) {
					if (wktSort[off + i] == wktGain[j]) {
						go = false;
						toDrop[j] = true;
						setNeighborToDrop(j, true);
					}
				}
			}
		} else if (method.equals("low")) {
			/** Remove the wktGain values that are too low */
			for (int i = 0; i < this.degree(); i++) {
				if (max != 0 && wktGain[i] * 100 / max < threshold) {
					toDrop[i] = true;
					setNeighborToDrop(i, true);
				}
			}
		}

		/* Compute the node utility range 0 to MaxEffort */

		copnode.setUtility( (utility / (viewSize * gameStep)) - (rewireCount * cost) - (mcost/gameStep) );

		return;
	}

	public int getViewSize() {
		return viewSize;
	}

	public void setNeighborEffort(int i) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				other.effort[j] = ((CopNode) this.getNeighbor(i))
						.getMaxEffort();
				go = false;
			}
		}
	}

	public void setNeighborEffort(int i, int value) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				other.effort[j] = value;
				go = false;
			}
		}
	}

	public int getNeighborEffort(int i) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		int value = 0;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				value = other.effort[j];
				go = false;
			}
		}
		return value;
	}

	public void setNeighborGain(int i, int value) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				other.gain[j] = value;
				go = false;
			}
		}
	}

	public int getNeighborGain(int i) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		int value = 0;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				value = other.gain[j];
				go = false;
			}
		}
		return value;
	}

	public void setNeighborWktGain(int i, int value) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				other.wktGain[j] = value;
				go = false;
			}
		}
	}

	public int getNeighborWktGain(int i) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		int value = 0;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				value = other.wktGain[j];
				go = false;
			}
		}
		return value;
	}

	public void setNeighborInvestment(int i, int value) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				other.investment[j] = value;
				go = false;
			}
		}
	}

	public int getNeighborInvestment(int i) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		int value = 0;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				value = other.investment[j];
				go = false;
			}
		}
		return value;
	}

	public void setNeighborToPlay(int i, boolean value) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				other.toPlay[j] = value;
				go = false;
			}
		}
	}

	public void setNeighborToDrop(int i, boolean value) {
		CopNet other = (CopNet) this.getNeighbor(i).getProtocol(pID);
		boolean go = true;
		for (int j = 0; j < other.degree() && go; j++) {
			if (copnode.getID() == other.getNeighbor(j).getID()) {
				other.toDrop[j] = value;
				go = false;
			}
		}
	}
}
