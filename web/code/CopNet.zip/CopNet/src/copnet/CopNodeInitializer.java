package copnet;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
/**
 * CopNodeInitializer initialises some CopNodes parameters
 * 
 * 
 * 
 * 
 * @author  Stefano Ferriani
 * 
 * @version 1.0
 */


public class CopNodeInitializer implements Control {


//	--------------------------------------------------------------------------
//	Parameter
//	--------------------------------------------------------------------------
	/** Maximum effort value */
	public static final String PAR_MAXEFFORT = "maxEffort";
	
	/** Effort values distribution */
	public static final String PAR_DISTR = "distr";
	
	/** Mean peak values  */
	public static final String PAR_VALUE = "value";
	
	/** Filename to print out stats on node degree. */
	private static final String PAR_FILE_NAME = "filename";

//	--------------------------------------------------------------------------
//	Fields
//	--------------------------------------------------------------------------
	/** Maximum effort value */
	private int maxEffort;
	
	/** Effort values distribution */
	private String distr;
	
	/** Mean peak values  */
	private int value;
	
	/** Filename to read node effort. */
	private final String fileName;

	
	private FileReader fr = null;
    private BufferedReader br = null;


	


	

//	------------------------------------------------------------------------
//	Constructor
//	------------------------------------------------------------------------
	/**
	 * Standard constructor that reads the configuration parameters. Invoked by
	 * the simulation engine.
	 * 
	 * @param prefix
	 *            the configuration prefix for this class.
	 */ 
	public CopNodeInitializer(String prefix) {
		maxEffort = Configuration.getInt(prefix + "." + PAR_MAXEFFORT, 10);		
		distr = Configuration.getString(prefix + "." + PAR_DISTR, "cost");
		value = Configuration.getInt(prefix + "." + PAR_VALUE, 2);
		fileName=Configuration.getString(prefix + "." + PAR_FILE_NAME, "init/init.dat");
		
		
	}


//	------------------------------------------------------------------------
//	Methods
//	------------------------------------------------------------------------
	/**
	 * Initialize the node effort. The effort distribution is defined by the
	 * configuration param distrib
	 */

	public boolean execute() {

		
		CopNode node;
		/** Constant distribution */
		if (distr.equals("cost")){
			for (int i = 0; i < Network.size(); i++) {
				node = (CopNode)Network.get(i);
				node.setMaxEffort(maxEffort);
			}			
		}
		/** Random distribution */
		else if (distr.equals("rnd")){
			for (int i = 0; i < Network.size(); i++) {
				node = (CopNode)Network.get(i);
				node.setMaxEffort(CommonState.r.nextInt(maxEffort+1));
			}			
		}
		/** Peak distribution */
		else if (distr.equals("peak")){
			double gauss;
			for (int i = 0; i < Network.size(); i++) {
				node = (CopNode)Network.get(i);
				gauss = CommonState.r.nextPoisson(value);
				node.setMaxEffort((int)gauss);
			}		
		}
		/** Tribe */
		else if (distr.equals("tribe")){
			int deltaEffort=maxEffort/value;
			int deltaNode=Network.size()/value;
			for (int i=0; i < value; i++){
				for (int j=0; j < Network.size()/value; j++){
					node = (CopNode)Network.get(j+deltaNode*i);
					node.setMaxEffort(deltaEffort*(1+i));
				}
			}
		}
		
		/** File */
		else if (distr.equals("file")){
			
			
			try {
				String str = null;
				String [] temp = null;
			     
				int number=0;
				int effort=0;
				
			    fr = new FileReader(fileName);
				
			    br = new BufferedReader(fr);


			    int i=0;
			    while (( str = br.readLine()) != null){

	
			    	temp = str.split(" ");
			    	
		
			    	
			    	number=Integer.parseInt(temp[1]);
			    	effort=Integer.parseInt(temp[0]);
			    	
			    	for (int j=0; j<number; j++){
						node = (CopNode)Network.get(i);
						node.setMaxEffort(effort);
						i++;
//						System.out.println(i+" Effort - "+effort);
			    	}
			    }

			    br.close();			    
			    fr.close();
			    
			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}
		
		/** Unknown distribution */
		else {
            System.out.println("ERROR *** Effort distribution "+distr+" is unknown");
            return true;
		}
		return false;
	}
	
}
